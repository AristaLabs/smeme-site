# ACME cross-border withholding - synthetic evidence dataset

Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.

Dataset version: `0.2.0-phase2-partial`
Sample key: `smeme_acme_xborder_withholding_v1`

## What this is

Eight fictional matters, each a directory of case sources, built so that a host application can run a
SMEme reasoning session end to end: receive one question at a time, search the sources, propose a
single answer with a provenance reference, pause for a person to admit, correct, reject, or abstain,
and continue until SMEme returns a report.

The matters differ in how complete their evidence is, how consistent their records are, how recent
their documents are, and how much document history sits behind them. Those differences are properties
of the files themselves and are not catalogued here. Read the documents.

The sources are deliberately spread across an agreement extract, email, CRM and registry records, a
payment schedule, extracted tax-form metadata, an intake memorandum, an API response, and short human
notes, written in different voices. 

## What this is not

This bundle does not contain the decision tree, the questions, the option strings, the branch
structure, or any expected answer or outcome, and it does not describe what any individual matter is
meant to demonstrate.

## Layout

```
README.md                     this file
SYNTHETIC_DATA_NOTICE.md      full notice and scope statement
dataset_manifest.json         source inventory
distributed/                  matter-123 through matter-130
```

## How a host should use these

1. Open a session and take one question at a time.
2. Search the case directory. Read document versions, effective dates, and supersession notices; a
   document that reads cleanly on its face may not be the latest word in the file.
3. Propose exactly one option, and attach the source ID and a short exact excerpt you actually found.
   If the file does not answer the question, abstain and say so. Do not guess, and do not fill a gap
   from a neighbouring document that is about something else.
4. Stop and let a person decide. The person may admit the proposal, correct it, reject it, or decline
   to answer.
5. Continue until a report comes back.

## Sources that disagree

Some matters contain records that cannot all be true. Detecting and presenting that is the host's job,
and resolving it is the person's job, before anything is admitted. Once a person has chosen what to
admit, the reasoning engine works on the admitted answers. It is not a referee between your sources
and it does not decide which of your documents is authoritative or current.

A person facing a conflict has more than one honest move: resolve it and admit an answer, admit that
the position is uncertain if the procedure offers that, or admit nothing and leave the evaluation
incomplete. Those are different acts.

## Provenance

A provenance reference records where a proposed answer came from. It does not establish that the
source is true, authoritative, current, or legally sufficient.

## Substantive review status

The decision procedure behind this dataset encodes tax rules, rates, citations, and 2026 statements
that **have not been reviewed by qualified tax counsel**. The synthetic-data notice above is
necessary but it is not a substitute for that review. Do not present this material as a realistic
legal artifact, to a client or to a prospect, until a qualified professional has reviewed the
substantive content.

## Full notice

- ACME, Inc., party D, matter numbers, people, records, and transactions are fictional.
- Any resemblance to real people, organizations, or transactions is coincidental.
- The example does not claim to encode complete or current tax law.
- Provenance records where an answer came from; it does not establish that a source is true, authoritative, current, or legally sufficient.
- A qualified professional must independently review real decision procedures and evidence.
