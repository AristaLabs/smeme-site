# Synthetic data notice

Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.

ACME, Inc., party D, matter numbers, people, records, and transactions are fictional.

Any resemblance to real people, organizations, or transactions is coincidental.

The example does not claim to encode complete or current tax law.

Provenance records where an answer came from; it does not establish that a source is true, authoritative, current, or legally sufficient.

A qualified professional must independently review real decision procedures and evidence.

No real taxpayer identifiers, addresses, credentials, account numbers, signatures, personal data, or live private URLs appear anywhere in this bundle. Email addresses use the reserved `.invalid` top-level domain. Register numbers, vendor IDs, and message IDs are invented. Bank and account details are described only by country of record and never by number.

Dataset version: `0.2.0-phase2-partial`

## Substantive review status

The tax rules, rates, citations, and 2026 statements encoded in the underlying decision procedure have not been reviewed by qualified tax counsel.
