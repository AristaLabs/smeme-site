---
source_id: ACME-MATTER-130-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-130/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-130
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

Standard royalty file. Quarterly payment under Section 4.4, Party D performs nothing here under
Section 4.6, no W-8ECI.

On hosting: finance publishes a regional revenue export by territory and Exhibit F to the agreement
lists the same three regions. Both are commercial cuts. Where the software executes is governed by
Section 4.2(b) and confirmed by infrastructure, who have the production cluster in Ashburn and warm
standby in Hillsboro with nothing outside the United States.
