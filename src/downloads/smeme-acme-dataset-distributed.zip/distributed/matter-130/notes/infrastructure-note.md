---
source_id: ACME-MATTER-130-NOTE-001
title: Infrastructure note
relative_locator: distributed/matter-130/notes/infrastructure-note.md
locator_kind: markdown-note
source_system: Meeting notes (fictional)
created_or_observed: 2026-09-09
retrieved: 2026-09-16
subject_identifier: ACME-MATTER-130
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Meridiaan Control Platform - hosting

Asked infrastructure to confirm where the platform executes.

- Production cluster: Ashburn, Virginia.
- Warm standby: Hillsboro, Oregon.
- No instance, mirror, or edge cache outside the United States. We have not sought consent under
  Section 4.2(b) and have no plans to.
- Customers in EMEA and APAC connect back to the US clusters.
