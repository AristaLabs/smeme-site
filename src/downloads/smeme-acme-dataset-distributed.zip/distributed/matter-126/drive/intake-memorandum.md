---
source_id: ACME-MATTER-126-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-126/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-126
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

Opened this file this morning. What I can say so far:

Party D is a foreign entity, this is not a real property or partnership interest transaction, the
payment is a royalty under Section 4.4, and the platform is deployed on US infrastructure under
Section 4.2(b). Party D has not claimed effectively connected status and there is no W-8ECI.

I have not pulled the certificate, I have not gone past what vendor master asserts on their chapter 4
position, and I have done no diligence on any treaty position. More to follow this week.
