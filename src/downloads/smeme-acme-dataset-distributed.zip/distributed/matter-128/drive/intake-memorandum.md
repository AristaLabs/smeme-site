---
source_id: ACME-MATTER-128-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-128/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-128
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

Raising a records issue rather than an analysis.

Vendor onboarding recorded a Form W-9 for this payee and coded it as a US person when the vendor was
created in June. The same vendor record also carries a W-8BEN-E and a Netherlands country code, and the
agreement and the register both describe a Netherlands entity. Both cannot describe the same payee. My
guess is that the wrong onboarding packet was attached at creation, but I have not been able to confirm
that with the vendor team yet.

I am recording what each system says as it stands and escalating to Marcus.
