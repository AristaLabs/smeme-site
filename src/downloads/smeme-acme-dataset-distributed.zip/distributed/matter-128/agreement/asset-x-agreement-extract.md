---
source_id: ACME-MATTER-128-AGR-001
title: Asset X agreement extract
relative_locator: distributed/matter-128/agreement/asset-x-agreement-extract.md
locator_kind: markdown-extract
source_system: Contract repository (fictional)
created_or_observed: 2026-07-01
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-128
document_version: Execution version 3.2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Asset X Divestiture and Platform License Agreement (extract)

**Parties.** ACME, Inc. (Delaware) and Delft Meridiaan Instrumenten B.V. (Netherlands, "Party D").
Executed July 1, 2026, execution version 3.2.

## Section 4.2(b)
"The license granted under this Section 4.2 is granted solely for deployment on ACME server
infrastructure located within the United States, and ACME shall not deploy, mirror, or make the
Platform available from any facility outside the United States without Party D's prior written consent."

## Section 4.4 - Royalty
ACME shall pay Party D a quarterly royalty equal to four percent (4%) of ACME's net revenue
attributable to systems running the Platform, payable in arrears within thirty (30) days of each quarter end.

## Section 4.6 - Independence of the Licensor
"Party D performs no activities under this Agreement within the United States. Party D maintains no
office, fixed place of business, dependent agent, or employees within the United States, and all
development, maintenance, and support activities under this Agreement are performed at Party D's
facilities in Delft, Netherlands."

## Exhibit F - Sales Territories (informational)
North America, EMEA, APAC.
