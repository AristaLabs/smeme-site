---
source_id: ACME-MATTER-124-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-124/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-124
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

Quarterly payments under Section 4.4 for a platform licence deployed on our US clusters only,
Section 4.2(b). Party D performs nothing here under Section 4.6 and has never given us a W-8ECI.

Documentation is where this file stands. The certificate in the tax store was signed on October 1,
2022 and received on October 4. By its own terms a certificate of that kind runs through the end of
the third calendar year following signature, which put it out of date at the end of 2025. I sent a
solicitation for a replacement on July 30 and chased it again on August 21. Nothing has come back.

I would not code the September payment to a reduced rate on that certificate.
