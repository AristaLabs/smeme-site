---
source_id: ACME-123-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-123/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-123
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Matter 123 royalty payments to Party D

**Prepared by:** P. Raman, associate
**For:** M. Oyelaran
**Draft 2, September 10, 2026.** Draft 1 (August 28) predated my review of the executed agreement
and should not be relied on.

## What ACME is paying

Quarterly royalties under Section 4.4 of the executed agreement for the right to run Party D's
Meridiaan Control Platform. First payable quarter is Q3 2026. The Asset X purchase price runs the
other direction and is not ACME's withholding problem.

## Characterization

I treated this as a royalty rather than a service fee or a purchase of a copyrighted article. The
grant in Section 4.2 is a right to use the platform on an ongoing basis with the fee measured as a
percentage of net revenue, which is how I would expect a license to be structured rather than a
sale. No transfer of copyright ownership. No separately priced services component.

## Where the platform runs

Section 4.2(b) restricts deployment to ACME server infrastructure inside the United States.
Infrastructure confirmed that the production and standby clusters are in Ashburn and Hillsboro.
Exhibit F lists EMEA and APAC but that exhibit is about where ACME sells systems, not where the
software runs, and Section 4.2(b) would prohibit running it abroad anyway.

## Party D's own activities here

Section 4.6 is an express representation that Party D has no US office, fixed place of business,
dependent agent, or employees, and performs nothing here. Vendor onboarding and the business
register extract agree. Party D has not given us a W-8ECI and has not asserted that any of this
income is connected with a US business of its own.

## Documentation

W-8BEN-E on file since February 10, 2026, signed February 6, 2026. It is within its stated validity
period and I have no record of a change in circumstances notice from Party D.

## Open question I could not close

None that affect the royalty analysis. The insurance certificate item in the CRM is unrelated.
