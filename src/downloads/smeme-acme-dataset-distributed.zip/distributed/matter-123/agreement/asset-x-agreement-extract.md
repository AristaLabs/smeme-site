---
source_id: ACME-123-AGR-001
title: Asset X agreement extract
relative_locator: distributed/matter-123/agreement/asset-x-agreement-extract.md
locator_kind: markdown-extract
source_system: Contract repository (fictional)
created_or_observed: 2026-07-01
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-123
document_version: Execution version 3.2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Asset X Divestiture and Platform License Agreement (extract)

**Parties.** ACME, Inc., a Delaware corporation with offices in Orlando, Florida ("ACME"),
and Delft Meridiaan Instrumenten B.V., a besloten vennootschap organized under the laws of
the Netherlands ("Party D").

**Execution date.** July 1, 2026. Execution version 3.2. Supersedes draft version 2.7 circulated June 12, 2026.

---

## Recital C

Concurrently with ACME's divestiture of the Asset X instrumentation product line to Party D,
Party D wishes to grant, and ACME wishes to take, a license to the Meridiaan Control Platform
software and associated firmware so that ACME may continue to operate its installed base.

## Section 2.1 - Divestiture of Asset X

Party D shall purchase the Asset X product line, including tooling and inventory, for a single
payment of USD 14,200,000 payable at Closing. **Party D is the payer under this Section; ACME is
the payee.**

## Section 4.2 - Grant of License

Party D grants ACME a non-exclusive, non-transferable license to install, execute, and make
available the Meridiaan Control Platform.

> Section 4.2(b): "The license granted under this Section 4.2 is granted solely for deployment on
> ACME server infrastructure located within the United States, and ACME shall not deploy, mirror,
> or make the Platform available from any facility outside the United States without Party D's
> prior written consent."

## Section 4.4 - Royalty

ACME shall pay Party D a quarterly royalty equal to four percent (4%) of ACME's net revenue
attributable to systems running the Platform, payable in arrears within thirty (30) days of each
quarter end.

## Section 4.6 - Independence of the Licensor

> Section 4.6: "Party D performs no activities under this Agreement within the United States.
> Party D maintains no office, fixed place of business, dependent agent, or employees within the
> United States, and all development, maintenance, and support activities under this Agreement are
> performed at Party D's facilities in Delft, Netherlands."

## Section 9.3 - Withholding

Each party shall be entitled to deduct and withhold from any amount payable under this Agreement
such amounts as are required under applicable law, provided that the paying party shall use
reasonable efforts to obtain and act upon documentation furnished by the receiving party that
would reduce or eliminate such withholding.

## Section 11.1 - Notices

Notices to Party D: Meridiaanweg 44, 2611 Delft, Netherlands (fictional address).

## Exhibit F - Deployment Regions (informational)

Exhibit F lists the regional sales territories in which ACME markets systems running the Platform:
North America, EMEA, and APAC. **Exhibit F describes ACME's sales territories and does not modify
the deployment restriction in Section 4.2(b).**
