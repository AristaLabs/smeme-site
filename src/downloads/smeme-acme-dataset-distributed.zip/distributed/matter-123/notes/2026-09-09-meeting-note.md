---
source_id: ACME-123-NOTE-001
title: Meeting note
relative_locator: distributed/matter-123/notes/2026-09-09-meeting-note.md
locator_kind: markdown-note
source_system: Meeting notes (fictional)
created_or_observed: 2026-09-09
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-123
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Note - Sept 9 stand-up, tax ops

- Q3 run locks Sept 26, pays Sept 30. Need coding for Party D by the 25th.
- Priya: W-8BEN-E is in hand, she is doing a line by line pass this week.
- Someone asked whether the Asset X sale proceeds create a withholding question.
  Marcus: no, money moves the other way on that one.
- Reminder unrelated to this matter: the EU distributor insurance cert expires in November.
- Platform runs in Ashburn primary / Hillsboro standby. Infra confirmed on the call.
