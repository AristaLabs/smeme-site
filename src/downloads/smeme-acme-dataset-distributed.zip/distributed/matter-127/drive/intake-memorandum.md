---
source_id: ACME-MATTER-127-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-127/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-127
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

The royalty analysis follows our usual pattern up to the treaty question, and then it stops.

The certificate on file certifies Netherlands residence and identifies a limitation on benefits
provision consistent with a Netherlands corporation. Signed February 6, received February 10, and on
its face within its validity period.

The register extract I pulled on September 14 records a seat transfer out of the Netherlands, recorded
August 19 and stated to be effective August 1, with a successor entity in another jurisdiction. If that
is right, the certificate describes a state of affairs that no longer holds and we should have had a
change in circumstances notice within thirty days. We have not had one.

Party D's commercial contact wrote on September 8 that nothing has changed and that a reorganisation
project did not complete. She has offered written confirmation from their corporate secretary. That
has not arrived.

This needs Marcus before anything is coded.
