---
source_id: ACME-MATTER-129-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-129/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-129
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

Two records describe the payee's position.

The February certificate is the one the file has used all year. Signed February 6, received February 10,
stated validity through the end of 2029, Netherlands residence, article and limitation on benefits
provision both identified.

On August 25 Party D sent a change in circumstances notice saying beneficial ownership of the royalty
stream was assigned to a group affiliate effective August 1, and that the affiliate sits in a
jurisdiction with no income tax treaty in force with the United States. No replacement certificate has
arrived.

The Q3 payment is scheduled for September 30. Marcus should decide which record governs it before the
run locks on the 26th.
