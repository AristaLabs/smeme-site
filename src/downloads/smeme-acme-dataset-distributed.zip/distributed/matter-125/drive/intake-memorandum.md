---
source_id: ACME-MATTER-125-MEM-001
title: Associate intake memorandum
relative_locator: distributed/matter-125/drive/intake-memorandum.md
locator_kind: markdown-document
source_system: Cloud drive (fictional)
created_or_observed: 2026-09-10
retrieved: 2026-09-15
subject_identifier: ACME-MATTER-125
document_version: draft 2
synthetic: true
synthetic_data_notice: >-
  Fictional technical demonstration only. This decision tree and its synthetic case files are provided solely to demonstrate SMEme and LangGraph integration. They are incomplete and are not legal, tax, accounting, compliance, or other professional advice. They must not be used to determine obligations in any real transaction.
---
# Intake memorandum - Party D royalty

The commercial side is clear. Quarterly royalty under Section 4.4, platform deployed only on US
infrastructure under Section 4.2(b), Party D performs nothing here under Section 4.6 and has given us
no W-8ECI. Vendor master carries their chapter 4 status as an active NFFE and they are not a
financial institution.

The certificate itself is not in the file. Tax operations migrated document storage in August and the
Party D W-8BEN-E did not come across. The vendor master records a W-8 series form as received on
February 10, 2026, but that is a receipt flag and carries none of the contents, so I cannot tell you
what is on Part I or Part III, whether an article is cited, whether a limitation on benefits provision
is identified, or whether it is signed.

Either we pull the document from the archive or we ask Party D for a fresh copy before the payment run.
